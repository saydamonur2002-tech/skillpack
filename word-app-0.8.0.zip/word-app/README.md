# Word App 0.8.0

See catalog.json for the candidate skills.
