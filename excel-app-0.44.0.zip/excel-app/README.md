# Excel App 0.44.0

47 candidate Skillpacks. Three packages updated for Google Sheets XLSX interoperability. Official Runner and external acceptance remain open.
